
#include "../includes/minishell.h"

static char *find_line(char **content)
{
	int i;
	char *str;
	char *tmp;

	i = 0;

	while (*(*content + i) && *(*content + i) != '\n')
		i++;
	if (*(*content + i) == '\n')
	{
		*(*content + i) = '\0';
		i++;
	}
	str = ft_strdup(*content);
	tmp = ft_strdup(*content + i);
	free(*content);
	*content = tmp;
	return (str);
}

int get_next_line(const int fd, char **line)
{
	int nb;
	char buf[BUFF_SIZE + 1];
	static char *inputcont[1];
	char *tmp;

	if (fd < 0 || line == NULL ||(read(fd, buf, 0) < 0))
		return (-1);

	while ((nb = read(fd, buf, BUFF_SIZE)) > 0)
	{
		if (!inputcont[fd])
			inputcont[fd] = ft_strnew(1);
		buf[nb] = '\0';
		tmp = ft_strjoin(inputcont[fd], buf);
		free(inputcont[fd]);
		inputcont[fd] = tmp;
		tmp = NULL;
		if (ft_strchr(buf, '\n') != NULL)
			break ;
	}
	if (nb == 0 && inputcont[fd] == NULL)
		return (-1);
	if (*inputcont[fd] == '\0') //
		return (0);
	*line = find_line(&inputcont[fd]);
	return (1);
}

void clean_env(char ***env_cp)
{
	int i;
	int j;

	i = 0;
	j = 0;
	while (env_cp[i])
		i++;
	while (j < i)
	{
		ft_strdel(env_cp[j]);
		j++;
	}
	free(*env_cp);
	*env_cp = NULL;
}

char	*path(char *name, char *path)
{
	char	*full;
	char	*tmp;

	if (path[ft_strlen(path) - 1] == '/')
		return (ft_strjoin(path, name));
	else
	{
		tmp = ft_strjoin(path, "/");
		full = ft_strjoin(tmp, name);
		ft_memdel((void **)&tmp);
	}
	return (full);
}

int get_val_index(char *name)
{
	int i;

	i = 0;
	while (g_env[i])
	{
		if (!(ft_strcmp(g_env[i], name)) && g_env[i][ft_strlen(name)] == '=')
			return(i);
		i++;
	}
	return (0);
}

//int unsetenv_cmnd(char *name) //need to finish
////{
////	int i;
////	int j;
////	char **env;
////	int index;
////
////	if (!name)
////	{
////		ft_putstr("usage: unsetenv [name]");
////		return (1);
////	}
////	env = g_env;
////	i = 0;
////	while(env[i])
////	{
////		if (!(index = get_var_index(env[i])))
////			continue ;
////
////
////	}
////
////
////	return (1); // continue to execute
////}

int cd_cmnd(char **args)
{
  if ((args[2]))
  {
    ft_putstr("cd: string not in pwd: ");
    ft_putstr(args[1]);
    ft_putchar('\n');
    return (1);
  }
  else if (!(args[1]))//change
    ft_putstr("where's ur fckn arg?\n");
  else
  {
    if ((chdir(args[1])))
      perror("minishell");
  }
  return (1); // continue to execute
}


int check_setenv(char **env)
{
	int i;

	i = 0;
	while (env[++i])
		if (!(ft_strchr(env[i], '=')))
		{
			perror("minishell");
			return (0);
		}
	return (1);
}

void print_env(char **env)
{
	int i;

	i = 0;
	while (env[i])
	{
	ft_putstr(env[i]);
	ft_putchar('\n');
	i++;
	}
}

int env_cmnd()
{
  if (!(check_setenv(g_env)))
 	 return(1);
  print_env(g_env);
  return (1);  //continue to execute
}

char *joinenv(char *name, char *value)
{
	char *tmp1;
	char *tmp2;

	if (!(tmp1 = ft_strjoin(name, "=")))
		perror("minishell"); //malloc()
	if (!(tmp2 = ft_strjoin(tmp1, value)))
		perror("minishell"); // malloc()
	ft_memdel((void **)&tmp1);
	return(tmp2);
}

int setenv_cmnd(char *name, char *value)
{
	int i;
	char **new_env;

	if (!name && !value)
		ft_putstr("usage: setenv [name] [value]"); //not enough arguments
	if ((i = get_val_index(name)))
		{
//		free(g_env[i]);
		g_env[i] = joinenv(name, value);
		}
	else
	{
		while (g_env[i])
			i++;
		if (!(new_env = (char**)malloc(sizeof(char *) * (i + 2))))
			perror("minishell");
		i = 0;
		while (g_env[i])
		{
//			ft_strcpy(new_env[i], g_env[i]);
			new_env[i] = g_env[i];
			i++;
		}
		new_env[i] = joinenv(name, value);
		new_env[i++] = NULL;
		clean_env(&g_env);
		g_env = new_env;
		print_env(g_env);
	}
	return (1);
}

int echo_cmnd(char **args)
{
  int i;

  i = 1;
  while (args[i])
  {
    ft_putstr(args[i++]);
    if (args[i++])
      ft_putchar(' ');
  }
  return (1); //continue to execute
}

int exit_cmnd()
{
//	clean_env(&env);
  return (0); // stop to execute
}

int builtin(char **args)
{
	printf("%s", args[0]);
  if (ft_strcmp(args[0], "cd") == 0)
    return (cd_cmnd(args));
  if (ft_strcmp(args[0], "env") == 0)
    return (env_cmnd());
  if (ft_strcmp(args[0], "setenv") == 0)
    return (setenv_cmnd(args[1], args[2]));
//  if (ft_strcmp(args[0], "unsetenv") == 0)
//    return (unsetenv_cmnd(args[1]));
  if (ft_strcmp(args[0], "echo") == 0)
    return (echo_cmnd(args));
  if (ft_strcmp(args[0], "exit") == 0)
    return (exit_cmnd());
  return (1);
}

char	*getenv_cmnd(char *name)
{
	int i;

	if ((i = get_val_index(name)))
		return (g_env[i] + ft_strlen(name) + 1);
	return (NULL);

}

int launch(char *file, char **args)
{
	pid_t pid;
	int status;

	pid = fork(); // make copy of process (child)
	if (pid == 0) // child process
	{
		if (execve(file, args, g_env) == -1) //replace current running process with new one
			perror("minishell");
		exit(EXIT_FAILURE);
	}
	else if (pid < 0) // fork error
		perror("minishell");
	else // parent process
	{
		waitpid(pid, &status, WUNTRACED); // приомтанавливает родительский процесс (PID процесса), пока дочерний процесс не завершится или до появления сигнала
		while (!WIFEXITED(status) && !WIFSIGNALED(status)) //макросы: WIFEXITED != 0, если дочерний процесс завершен, WIFSIGNALED - ывозвращет истинное значение,если дочерний процесс завершился из-за необработанного сигнала
			waitpid(pid, &status, WUNTRACED);
	}
	return (1); //continue to execute
}

int		find_bin(char *cmnd_name, char *path)
{
	DIR				*dir;
	struct dirent	*dir_ptr;

	dir = opendir(path);
	while ((dir_ptr = readdir(dir)))
		if (ft_strcmp(dir_ptr->d_name, cmnd_name) == 0)
		{
			closedir(dir);
			return (1);
		}
	closedir(dir);
	return (0);
}

int external_launch(char **cmnd, char *paths)
{
	struct stat s;
	char *filepath;

	if (access(cmnd[0], X_OK) == -1)
		perror("minishell");
	if ((lstat(cmnd[0], &s)) == -1)
		perror("minishell");

	filepath = path(cmnd[0], paths);
	return (launch(filepath, cmnd));

}

int		check_extern_command(char **cmnd)
{
	char	*env_path;
	char	**paths;
	int		i;

	env_path = getenv_cmnd("PATH");
	paths = ft_strsplit(env_path, ':');
	i = 0;
	while (paths[i]) //seg
	{
		if ((find_bin(paths[i], cmnd[0])))
		{
			external_launch(cmnd, paths[i]);
//			clean_env(&paths);
			return (1);
		}
		i++;
	}
	perror("minishell"); //no file or directory
//	clean_env(&cmnd);
	return (0);
}


int		check_builtin(char *cmnd)
{
	if (ft_strcmp(cmnd, "cd") == 0)
		return (1);
	if (ft_strcmp(cmnd, "env") == 0)
		return (1);
	if (ft_strcmp(cmnd, "echo") == 0)
		return (1);
	if (ft_strcmp(cmnd, "setenv") == 0)
		return (1);
	if (ft_strcmp(cmnd, "unsetenv") == 0)
		return (1);
	if (ft_strcmp(cmnd, "exit") == 0)
		return (1);
	return (0);
}

int		absolute_path_launch(char **cmnd)
{
	struct stat s;

	if (access(cmnd[0], X_OK) == -1)
		perror("minishell");
	if ((lstat(cmnd[0], &s)) == -1)
		perror("minishell");
	return (launch(cmnd[0], cmnd));
}

int external_cmnd(char **cmnd)
{
	if (*cmnd[0] == '/' || *cmnd[0] == '.')
		absolute_path_launch(cmnd);
	else
		check_extern_command(cmnd);
	return (1); //continue to execute
}

int execute_cmnd(char **cmnd)
{
	int execute_status;
//
////	execute_status = 1;// del
//	if (cmnd[0] == NULL) //emp ty command
//		return (1); //continue to execute
//	if (check_builtin(cmnd[0]) == 1)
		execute_status = builtin(cmnd);
//	else
//		execute_status = external_cmnd(cmnd);
//
//////	execute_status = launch(cmnd_args);
//////	clean_env(&cmnd_args); //chng
	return (execute_status);
//return(1);
}
char **make_env_cp(char **env_dst, char **env_origin)
{
	int i_origin;
	int j_dst;

	i_origin = 0;
	j_dst = 0;
	while (env_origin[i_origin])
		i_origin++;
	env_dst = (char **)malloc(sizeof(char *) * (i_origin + 1));
	while (j_dst < i_origin)
	{
		env_dst[j_dst] = ft_strdup(env_origin[j_dst]);
		j_dst++;
	}
	env_dst[j_dst] = NULL;
//	int k = 0;
//	while (env_dst[k])
//		printf("%s", env_dst[k++]);
	return(env_dst);
}

void	print_usage(void)
{
	ft_putstr("usage: minishell\n");
}

char **split_cmnds(char **full_cmnd)
{
	int i;
	int argc;
	char **cmnd_args;

	argc = 0;
	i = 0;
	while (full_cmnd[argc])
		argc++;
	if (!(cmnd_args = (char **)malloc(sizeof(char *) * (argc + 1))))
		perror("minishell");
	while (i < argc)
	{
		cmnd_args[i] = ft_strdup(full_cmnd[i]);
		i++;
	}
	cmnd_args[i] = NULL;
	return (cmnd_args);
}


char *space_clean(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
		if (str[i] == ' ' || str[i] == '\v' || str[i] == '\r' || str[i] == '\f' || str[i] == '\t')
			i++;
	return(str + i);
}

void cmnd_loop()
{
	char *line;
	char **args;
//	char **cmnd_args;
	int i;
	int execution;
	int flag;

	execution = 1;
	//flag = 0;
	args = NULL;
//	ft_putstr(SHELL_NAME);
	line = NULL;
int argc;

	while (execution)
	{
		flag = 0;
		ft_putstr(SHELL_NAME);
		get_next_line(STDIN_FILENO, &line);
//		if ((get_next_line(STDIN_FILENO, &line)))
//		{
//
		if (line)
		{
			ft_putstr("ur moron\n");
//			if ((strrchr(line, ';'))) {
//				if (!(args = ft_strsplit(line, ';')))
//					perror("minishell");
//				flag = 1;
//			}
//			if (flag)
//			{
//				i = 0;
//				while (args[i]) {
//
//					execution = execute_cmnd(ft_strsplit(args[i], ' ')); //exit code 11
//					if (execution == 0)
//						continue;
//					ft_putstr(args[i]);
//					ft_putchar('\n');
//					i++;
//				}
//			}
//			else
//				{
//				execution = execute_cmnd(ft_strsplit(line, ' '));

//
ft_strdel(&line);
		}
	}
//	free(args);




//	if (status)
//		cmnd_loop();

//	if (get_next_line(STDOUT_FILENO, &line) == 1)
//	{
//
//		if (ft_strrchr(line, ';')) {
//			if (!(args = ft_strsplit(line, ';')))
//				perror("minishell");
//			many = 1;
//
//		}
//		i = 0;
//		if ((many)) {
//			while (args[i]) {
//				status = execute_cmnd(ft_strsplit(args[i], ' '));
//				if (status == 0)
//					continue;
//				i++;
//			}
//		} else {
//			status = execute_cmnd(ft_strsplit(line, ' '));
//		}

//	cmnd_args = split_cmnds(args);
//		int k = 0;
//	while (cmnd_args[k])
//		printf("%s", cmnd_args[k++]);
//	while (args[i])
//	{
//		status = execute_cmnd(ft_strsplit(args[i], ' '));
//		if (status == 0)
//			continue;
//		i++;
//	}
////	while (execute_cmnd(args, env))
////	{
////	ft_putstr(SHELL_NAME);
////		get_next_line(STDOUT_FILENO, &line);
////		args = ft_strsplit(line, ';');
////	}
//		free(line);
//		free(args);
//	}
//	if (status)
//		cmnd_loop();
}

int main(int argc, char **argv, char **env)
{
	// configs
	char **env_cp;

	env_cp = NULL;
	argv = NULL;
	if (argc == 1)
	{
	 env_cp = make_env_cp(env_cp, env);
	 g_env = env_cp;
////		g_env = make_env_cp(g_env, env);
		cmnd_loop();
	///	// exit, cleanup
////		clean_env(&env_cp); //change
	}
	else
		print_usage();
	env = NULL;
	return (0);
}


