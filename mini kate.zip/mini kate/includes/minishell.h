#ifndef MINISHELL_H
# define MINISHELL_H

# include "libft.h"
//#include "get_next_line.h"

# include <stdlib.h>
# include <sys/types.h>
# include <sys/wait.h>
# include <sys/stat.h>
# include <unistd.h>
# include <dirent.h>



# define BUFF_SIZE 1000


#include <stdio.h>
#include <string.h>

#include <signal.h>

char **g_env;

#define SHELL_NAME "\e[95m\e[1mminishell\e[0m🌚 "
#define LINE_BUFSIZE 1024
#endif
