
#include "../includes/minishell.h"

void rewrite_env(int index)
{
	char	**env;
	short	i;
	int str_quan;

	str_quan = str_quantity();
	if (!(env = (char**)malloc(sizeof(char *) * str_quan)))
		perror_cmnd("unsetenv", NULL, MLKERR);
	i = 0;
	while (g_env[i] && g_env[i + 1])
	{
		if (i < index)
			env[i] = g_env[i];
		else
		{
			if (i == index)
				ft_memdel((void**)&(g_env[i]));
			env[i] = g_env[i + 1];
		}
		i++;
	}
	env[str_quan] = NULL;
	free(g_env);
	g_env = env;
}

int unsetenv_cmnd(char *name) //need to finish
{
	int index;

	if (!name)
	{
		ft_putstr("usage: unsetenv [name]");
		return (1);
	}
	if (g_env)
	{
		if ((index = get_envindex(name)) == -1)
			return (1);
		rewrite_env(index);
	}
	return (1); // continue to execute
}
