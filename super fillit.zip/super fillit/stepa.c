/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stepa.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bellyn-t <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/04/25 16:09:18 by bellyn-t          #+#    #+#             */
/*   Updated: 2019/04/25 16:35:37 by bellyn-t         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/fill.h"
#include "libft/libft.h"

int        check_desk_opportunity(t_mark *start, t_tetr *tetr, int desk_size)
{
    if ((start->row + tetr->height) <= desk_size &&
        (start->col + tetr->width - br_mv(tetr)) <= desk_size)
        return (1);
    return (0);
}
