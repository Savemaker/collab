/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   validation.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbeqqo <gbeqqo@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/04/23 16:25:56 by gbeqqo            #+#    #+#             */
/*   Updated: 2019/04/24 20:23:15 by bellyn-t         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/fill.h"
#include "libft/libft.h"

int		br_mv(t_tetr *tetr)
{
	int i;

	i = 0;
	while (tetr->shape[0][i] == '.')
		i++;
	return (i);
}

void	valid_line(char *line, int *is_it_last_fig)
{
	int len;
	int brick;
	int str_count;

	brick = 0;
	len = 0;
	while (line[len])
	{
		str_count = len / 5;
		if ((len + 1 % 5 == 0 && line[len] != '\n') ||
	(line[len] != '.' && line[len] != '#' && line[len] != '\n'))
			stop();
		if ((len + 1) % 5 != 0 && str_count < 4 &&
		((line[len] != '.' && line[len] != '#')))
			stop();
		if (line[len] == '#')
			brick++;
		len++;
	}
	str_count = len / 5;
	if (line[20] == '\0')
		*is_it_last_fig = 1;
	if (!brick || brick != 4 || str_count != 4)
		stop();
}

void	valid_newlines(char *tetrline)
{
	int i;

	i = 19;
	while (i > 0)
	{
		if (tetrline[i] != '\n')
			stop();
		i = i - 5;
	}
	if (tetrline[20] != '\n' && tetrline[20] != '\0')
		stop();
}

void	valid_fig_continue(char *tet)
{
	if (*(tet + 1) == '#' && *(tet + 2) == '#' && *(tet + 7) == '#')
		;
	else if (*(tet + 5) == '#' && *(tet + 6) == '#' && *(tet + 11) == '#')
		;
	else if (*(tet + 1) == '#' && *(tet + 4) == '#' && *(tet + 5) == '#')
		;
	else if (*(tet + 4) == '#' && *(tet + 5) == '#' && *(tet + 9) == '#')
		;
	else if (*(tet + 1) == '#' && *(tet + 6) == '#' && *(tet + 7) == '#')
		;
	else if (*(tet + 4) == '#' && *(tet + 5) == '#' && *(tet + 6) == '#')
		;
	else if (*(tet + 4) == '#' && *(tet + 5) == '#' && *(tet + 10) == '#')
		;
	else if (*(tet + 5) == '#' && *(tet + 6) == '#' && *(tet + 10) == '#')
		;
	else if (*(tet + 5) == '#' && *(tet + 9) == '#' && *(tet + 10) == '#')
		;
	else if (*(tet + 1) == '#' && *(tet + 5) == '#' && *(tet + 10) == '#')
		;
	else if (*(tet + 1) == '#' && *(tet + 2) == '#' && *(tet + 6) == '#')
		;
	else
		stop();
}

void	valid_fig(char *tet)
{
	while (*tet != '#')
		tet++;
	if (*(tet + 5) == '#' && *(tet + 10) == '#' && *(tet + 15) == '#')
		;
	else if (*(tet + 1) == '#' && *(tet + 2) == '#' && *(tet + 3) == '#')
		;
	else if (*(tet + 1) == '#' && *(tet + 5) == '#' && *(tet + 6) == '#')
		;
	else if (*(tet + 5) == '#' && *(tet + 10) == '#' && *(tet + 11) == '#')
		;
	else if (*(tet + 1) == '#' && *(tet + 6) == '#' && *(tet + 11) == '#')
		;
	else if (*(tet + 2) == '#' && *(tet + 6) == '#' && *(tet + 11) == '#')
		;
	else if (*(tet + 1) == '#' && *(tet + 2) == '#' && *(tet + 5) == '#')
		;
	else if (*(tet + 3) == '#' && *(tet + 4) == '#' && *(tet + 5) == '#')
		;
	else if (*(tet + 5) == '#' && *(tet + 6) == '#' && *(tet + 7) == '#')
		;
	else
		valid_fig_continue(tet);
}
