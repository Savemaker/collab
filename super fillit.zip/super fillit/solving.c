/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solving.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbeqqo <gbeqqo@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/04/23 16:14:44 by gbeqqo            #+#    #+#             */
/*   Updated: 2019/04/25 15:51:45 by bellyn-t         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/fill.h"
#include "libft/libft.h"

int		blank(char **desk, t_mark *start, t_tetr *tetr, int desk_size)
{
	char	**shape;
	int		row;
	int		col;

	if (!(check_desk_opportunity(start, tetr, desk_size)))
		return (0);
	shape = tetr->shape;
	row = 0;
	while (shape[row] != NULL && row < tetr->height &&
	(row + start->row) < desk_size)
	{
		col = 0;
		while (shape[row][col] != '\0' && col + start->col <= desk_size)
		{
			if (desk[row + start->row][col + start->col - br_mv(tetr)] != '.' &&
				shape[row][col] != '.')
				return (0);
			col++;
		}
		row++;
	}
	return (1);
}

int		next_position(char **desk, t_mark *mark, t_tetr *tetr, int desk_size)
{
	mark->col = mark->col + 1;
	while (desk[mark->row] != NULL)
	{
		while (desk[mark->row][mark->col] != '\0')
		{
			if (desk[mark->row][mark->col] == '.' &&
				check_desk_opportunity(mark, tetr, desk_size))
				return (1);
			mark->col++;
		}
		mark->row = mark->row + 1;
		mark->col = 0;
	}
	return (0);
}

int		solving(t_list *tetr_lst)
{
	int		fig_count;
	t_mark	*start;
	t_desk	*wow_desk;

	fig_count = (int)(tetr_lst)->content_size;
	start = create_marks(0);
	wow_desk = (t_desk *)ft_memalloc(sizeof(wow_desk));
	wow_desk->desk_size = sizeof_desk(fig_count, tetr_lst);
	wow_desk->desk_shape = draw_desk(wow_desk->desk_size);
	while (!(fillit(tetr_lst, wow_desk, start, fig_count)))
	{
		clean_desk(wow_desk->desk_shape, wow_desk->desk_size);
		wow_desk->desk_size += 1;
		if (!(wow_desk->desk_shape = draw_desk(wow_desk->desk_size)))
			return (0);
		start->row = 0;
		start->col = 0;
	}
	print_desk(wow_desk->desk_shape);
	clean_desk(wow_desk->desk_shape, wow_desk->desk_size);
	free(wow_desk->desk_shape);
	return (1);
}

int		placing(char **desk, int desk_size, t_mark *start, t_tetr *tetr)
{
	int ok;

	while (!(ok = blank(desk, start, tetr, desk_size)))
	{
		if (!next_position(desk, start, tetr, desk_size))
			return (0);
	}
	return (ok);
}

char	**fillit(t_list *tetr_lst, t_desk *wow_desk, t_mark *start, int n_fig)
{
	t_tetr	*tetr;
	char	**repeat;
	char	**desk;
	int		desk_size;

	desk = wow_desk->desk_shape;
	desk_size = wow_desk->desk_size;
	tetr = (t_tetr *)(tetr_lst)->content;
	if (!placing(desk, desk_size, start, tetr))
		return (0);
	if (!(desk = insert_to_desk(desk, desk_size, start, tetr)))
		return (0);
	if (n_fig == 1)
		return (desk);
	else if (n_fig > 1 &&
			(repeat = fillit(tetr_lst->next,\
	wow_desk, create_marks(0), n_fig - 1)))
		return (repeat);
	else
	{
		delete_tetr_from_desk(desk, tetr);
		if (!next_position(desk, start, tetr, desk_size))
			return (0);
		return (fillit(tetr_lst, wow_desk, start, n_fig));
	}
}
