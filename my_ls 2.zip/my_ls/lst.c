#include "ft_ls.h"

t_dir	*create_new_node(uint16_t flags)
{
	t_dir	*lst;

	if (!(lst = (t_dir *)malloc(sizeof(t_dir))))
	{
		perror("ft_ls");
		exit(-1);
	}
	lst->next = NULL;
	lst->prev = NULL;
	lst->flags = flags;
	lst->gid = 0;
	lst->uid = 0;
	lst->name = NULL;
	lst->path = NULL;
	lst->mode = 0;
	lst->level = 0;
	return (lst);
}

t_dir	*push_file(t_dir **dir_head, t_dir *file_elem)
{
	t_dir	*head_ptr;

	head_ptr = *dir_head;
	while (head_ptr->next && define_mode(head_ptr->next->mode) == 'd')
		head_ptr = head_ptr->next;
	if (!(head_ptr->next))
	{
		file_elem = NULL;
		*dir_head = NULL;
	}
	else
		{
		file_elem = head_ptr;
		head_ptr->next = NULL;
	}
	return (file_elem);
}

t_dir	*make_file_list(t_dir *file_elem, t_dir **file_head)
{
	t_dir	*tmp;

	if (!(*file_head))
	{
		*file_head = file_elem;
		(*file_head)->prev = NULL;
	}
	else
	{
		tmp = *file_head;
		while (tmp->next != NULL)
			tmp = tmp->next;
		tmp->next = file_elem;
		file_elem->prev = tmp;
	}
	return (file_elem);
}

t_dir	*checkroot_andcreate(t_dir *dir, t_dir **head, uint16_t flags)
{
	t_dir *new;

	if (!(*head))
	{
		dir = create_new_node(flags);
		*head = dir;
	}
	else
	{
		new = create_new_node(flags);
		dir->next = new;
		new->prev = dir;
		dir = new;
	}
	return (dir);
}

t_dir	*make_argv_lst(char **argv, uint16_t flags, uint16_t *i)
{
	t_dir *dir;
	t_dir *dir_head;
	t_dir *file_head;
	char *name;
	char *path;
//	struct stat info;

	name = NULL;
	path = NULL;
	dir = NULL;
	dir_head = dir;
	file_head = NULL;
	while (argv[++(*i)]) //файлы и дир в аргументах
	{
		dir = checkroot_andcreate(dir, &dir_head, flags); // проверяется корень списка, создает лист
//		dir = create_new_node(flags);
		dir->name = check_name_from_path(argv[*i]);
		dir->path = ft_strdup(argv[(*i)]);
		if (!(stat_info(&dir))) // информация о дир // а если нет? //наверно, надо удалять дир// голову //ааа как много апдейта// у меня шиза?
		{
			//надо удалить голову этой дир
			continue ;
		}
		if (define_mode(dir->mode) == 'd')
		{
			dir->level = 1; //1 уровень директории
			dir = make_file_list(dir, &dir_head);
		}
		else if (!(define_flag(flags, 'd'))) //файлики и тп // при д нам в принципе нужны только директории
		{
			dir->level = 0; // вообще нет уровней
			dir = make_file_list(dir, &file_head);
			dir = push_file(&dir_head, dir); // файл, который прикидывается дир
		}
	}
	return (display_files(dir_head, file_head));
}

