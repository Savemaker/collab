#include "ft_ls.h"


void	print(t_dir *dir)
{
	struct winsize window;

	if (!dir)
		return ;
	//в структуру записать row, col терминала
//	if (ioctl(STDOUT_FILENO, TIOCGWINSZ, (char*)&window) < 0) // в случае успеха возвращается 0 (или неотрицательное значение), -1 при ошибке
//		exit(-1); //надо ли обработать ошибку?

	if (define_flag(dir->flags, 'd'))
	{
		if (define_flag(dir->flags, 'l') || define_flag(dir->flags, 'g'))
			print_rows
		else
			print_cols
		exit(0);
	}
	if (define_mode(dir->mode) != 'd') {
		if (define_flag(dir->flags, 'l') || define_flag(dir->flags, 'g'))
			print_rows
		else
			print_cols

		//free dir
		return;
	}
}

t_dir	*display_files(t_dir *dir_head, t_dir *file_head)
{
	if (file_head)
	{
		print(sorting(file_head, file_head->flags));
		if (dir_head)
		{
			dir_head->flags = define_flag(dir_head->flags, 1);
			return (sorting(dir_head, dir_head->flags));
		}
	}
	if (dir_head)
		return (sorting(dir_head, dir_head->flags));
	return (NULL);
}

t_dir	*basic_print(t_dir *list)
{
	while (list)
	{
		if (list->name[0] != '.')
		{
			ft_putstr(list->name);
			if (list->next != NULL)
				ft_putchar(' ');
		}
		list = list->next;
	}
	ft_putchar('\n');
	return (list);
}
