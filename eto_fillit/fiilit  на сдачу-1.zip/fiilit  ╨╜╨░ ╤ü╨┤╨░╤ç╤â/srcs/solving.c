#include "../includes/fill.h"
#include "../libft/libft.h"

//THIS

int check_desk_opportunity(t_mark *start, t_tetr *tetr, int desk_size)
{
	if ((start->row + tetr->height - 1) < desk_size && (start->col + tetr->width - 1) < desk_size)
		return (1);
	return(0);
}


//int col_brick_move(t_tetr *tetr)
//{
//    int i;
//
//    i = 0;
//    while (tetr->shape[0][i] == '.')
//        i++;
//    return (i);
//}

int blank(char **desk, t_mark *start, t_tetr *tetr, int desk_size)
{
	char **shape;
	int row;
	int col;

	if (!(shape = (char **)malloc(sizeof(**shape) * desk_size + 1)))
		stop();
	shape = tetr->shape;
	row = 0;
	while (shape[row])
	{
		col = 0;
	while (shape[row][col] != '\0') //seg
		{
			if ((desk[row + start->row][col + start->col] != '.') || shape[row][col] == '.' )
				return (0);
			col++;
		}
		row++;
	}
	return (1);
}

//int next_position(char **desk, t_mark *mark)
//{
//	(mark)->col = (mark)->col++;
//	while (desk[(mark)->row])
//	{
//		while(desk[(mark)->row][(mark)->col] != '\0')
//		{
//			if (desk[(mark)->row][(mark)->col] == '.')
//				return (1);
//			(mark)->col++;
//		}
//		(mark)->row++;
//		(mark)->col = 0;
//	}
//		return (0);
//}

//int next_position(char **desk, t_mark *mark, t_tetr *tetr, int desk_size)
//{
//	mark->col = mark->col++;
//	while (desk[mark->row])
//	{
//		while(desk[mark->row][mark->col] != '\0')
//		{
//			if ((desk[mark->row][mark->col] == '.' && mark->col + tetr->width - 1 < desk_size) && blank(desk, mark, tetr, desk_size))
//				return (1);
//			mark->col++;
//		}
//		mark->row++;
//		mark->col = 0;
//	}
//	return (0);
//}

int next_position(char **desk, t_mark *mark, t_tetr *tetr, int desk_size)
{
	mark->col = mark->col++;
	while (desk[mark->row])
	{
		while(desk[mark->row][mark->col] != '\0')
		{
//			if ((desk[mark->row][mark->col] == '.' && mark->col + tetr->width - 1 < desk_size))
			if (desk[mark->row][mark->col] == '.' && mark->col + tetr->width - 1 < desk_size && blank(desk, mark, tetr, desk_size))
				return (1);
			mark->col++;
		}
		mark->row++;
		mark->col = 0;
	}
	return (0);
}

//char **fillit(t_list *tetr_lst, char **desk, int desk_size, t_mark *start, int fig_count)
//{
//	t_tetr *tetr;
//
//	tetr = (t_tetr *)(tetr_lst)->content;
//	while (!(check_desk_opportunity(start, tetr, desk_size)))
//		return(0);
//
//
////	if (!blank(desk, start, tetr) && !next_position(desk, start))
////		return (0);
//
//	if (!blank(desk, start, tetr))
//		next_position(desk, start);
//
//	if (!(desk = insert_to_desk(desk, desk_size, start, tetr)))
//		return (0);
//	if (fig_count == 1)
//		return (desk);
//	else if (fig_count > 1)
//		fillit(tetr_lst->next, desk, desk_size, start, fig_count - 1);
//	else
//		delete_tetr_from_desk(desk, tetr);
//	return (0);
//}

//int fillit(t_list *tetr_lst, char **desk, int desk_size, t_mark *start, int fig_count)
//{
//	t_tetr *tetr;
//
//	tetr = (t_tetr *)(tetr_lst)->content;
//	while (!(check_desk_opportunity(start, tetr, desk_size)))
//		return(0);
//	if (!blank(desk, start, tetr) && !next_position(desk, start))
//		return (0);
//	if (!(desk = insert_to_desk(desk, desk_size, start, tetr)))
//		return (0);
//	if (fig_count == 1)
//		return (1);
//	else if (fig_count > 1)
//	{
//		fillit(tetr_lst->next, desk, desk_size, start, fig_count - 1);
//	}
//	else
//		delete_tetr_from_desk(desk, tetr);
//	return (1);
//}

//int fillit(t_list *tetr_lst, char **desk, int desk_size, t_mark *start, int fig_count)
//{
//	t_tetr *tetr;
//
//	tetr = (t_tetr *)(tetr_lst)->content;
//	while (!(check_desk_opportunity(start, tetr, desk_size)))
//		return(0);
//	if (!blank(desk, start, tetr) && !next_position(desk, start))
//		return (0);
//	if (!(desk = insert_to_desk(desk, desk_size, start, tetr)))
//		return (0);
//	if (fig_count == 1)
//		return (1);
//	else if (fig_count > 1)
//	{
//		fillit(tetr_lst->next, desk, desk_size, start, fig_count - 1);
//	}
//	else
//		delete_tetr_from_desk(desk, tetr);
//	return (1);
//}
//

//int placing(char **desk, int desk_size, t_mark *start, t_tetr *tetr)
//{
//	if (!blank(desk, start, tetr, desk_size))
//	{
//		if (!next_position(desk, start, tetr, desk_size))
//			return (0);
//		placing(desk, desk_size, start, tetr);
//	}
//	return(1);
//}

char **fillit(t_list *tetr_lst, char **desk, int desk_size, t_mark *start, int fig_count)
{
	t_tetr *tetr;
	char **repeat;

	tetr = (t_tetr *)(tetr_lst)->content;
	if (!(check_desk_opportunity(start, tetr, desk_size)))
		return(0);

//	if (!(placing(desk, desk_size, start, tetr)))
//		return (0);

	if (!blank(desk, start, tetr, desk_size) && !next_position(desk, start, tetr, desk_size)) // перекрывает фигуру
		return (0);

	if (!(desk = insert_to_desk(desk, desk_size, start, tetr)))
		return (0);
	if (fig_count == 1)
		return (desk);
	else if (fig_count > 1 && (repeat = fillit(tetr_lst->next, desk, desk_size, start, fig_count - 1)))
		return (repeat);
	else
		delete_tetr_from_desk(desk, tetr);
	return (NULL);
}


int solving(t_list *tetr_lst)
{
	char **desk;
	int fig_count;
	int desk_size;
	t_mark *start;

	fig_count = (int)(tetr_lst)->content_size;
	start = create_marks(0);
	desk_size = sizeof_desk(fig_count, tetr_lst);
	desk = draw_desk(desk_size);

	while (!(fillit(tetr_lst, desk, desk_size, start, fig_count)))
	{
		clean_desk(desk, desk_size);
		desk_size += 1;
		if (!(desk = draw_desk(desk_size)))
			return (0);
		start->row = 0;
		start->col = 0;
	}
	print_desk(desk);
	clean_desk(desk, desk_size);
	free(desk);
	return (1);
}