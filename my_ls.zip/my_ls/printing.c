#include "ft_ls.h"

t_dir	*printing(t_dir *dir_head, t_dir *file_head)
{
	if (file_head)
	{
		basic_print(sorting(file_head, file_head->flags));
//		if (dir_head)
//		{
//			dir_head = sorting(dir_head, dir_head->flags);
//			//	директории в 1 колонку надо отображать с названиями
//			return (dir_head);
//		}
	}
	if (dir_head)
		//ft_putstr("ble");
		return (basic_print(sorting(dir_head, dir_head->flags)));
//	basic_print(file_head);
//	basic_print(dir_head);
	return (NULL);
}

t_dir	*basic_print(t_dir *list)
{
	while (list)
	{
		if (list->name[0] != '.')
		{
			ft_putstr(list->name);
			if (list->next != NULL)
				ft_putchar(' ');
		}
		list = list->next;
	}
	ft_putchar('\n');
	return (list);
}
