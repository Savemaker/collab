#include "ft_ls.h"

//void	rows_output(t_dir *object, uint16_t ws_cols)
//{
//t_row_tty	row_struct;
//}