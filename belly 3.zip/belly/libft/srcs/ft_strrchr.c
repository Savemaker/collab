/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bellyn-t <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/03 14:32:14 by bellyn-t          #+#    #+#             */
/*   Updated: 2018/12/03 14:41:27 by bellyn-t         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strrchr(const char *s, int c)
{

  if (ft_strchr(s, c) == NULL)
    return (NULL);     
while (*s != '\0')
	  s++;
	while (*s != (char)c)
	  s--;
	return ((char *)s);
}
